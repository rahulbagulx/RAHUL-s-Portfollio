// JavaScript for sharing functionality

document.getElementById("shareBtn").addEventListener("click", async () => {
  if (navigator.share) {
    try {
      await navigator.share({
        title: "Check out @curious_coder_rahul's Profile!",
        url: window.location.href, // Share the current page URL
      });
      console.log("Profile shared successfully");
    } catch (error) {
      console.error("Error sharing profile:", error);
    }
  } else {
    alert("Sharing not supported on this browser");
  }
});
